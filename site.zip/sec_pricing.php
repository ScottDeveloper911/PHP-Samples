<!-- Price -->
<div class="container bg-pattern-01 my-5">
    <h1 class="pb-4 border-bottom text-center font-color-02">Pricing based on your needs</h1>
    <br>
    <br>
    <div class="row row-cols-1 row-cols-md-4 mb-3 text-center">
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card mb-4 rounded-3 shadow-sm" data-aos="flip-left" data-aos-duration="2000">
                <div class="card-header py-3">
                    <h3 class="">Emergency</h3>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">$85<small class="text-body-secondary fw-light">/hour</small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>Max 20 Hours / Month</li>
                        <li>Emergency Availability</li>
                        <li>24/7 On Call Support</li>
                        <li>No Minimum</li>
                    </ul>
                    <button id="pricecta01" type="button" class="w-100 btn btn-lg btn-primary hvr-float">Get Help Now</button>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card mb-4 rounded-3 shadow-sm" data-aos="flip-left" data-aos-duration="2000" data-aos-delay="100">
                <div class="card-header py-3">
                    <h3 class="">As Needed</h3>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">$60<small class="text-body-secondary fw-light">/hour</small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>Max 20 Hours / Month</li>
                        <li>Non-Emergency</li>
                        <li>Limited Support</li>
                        <li>No Minimum</li>
                    </ul>
                    <button id="pricecta02" type="button" class="w-100 btn btn-lg btn-primary hvr-float">Get started</button>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card mb-4 rounded-3 shadow-sm" data-aos="flip-left" data-aos-duration="2000" data-aos-delay="200">
                <div class="card-header py-3">
                    <h3 class="">Retainer Starter</h3>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">$2,000<small class="text-body-secondary fw-light">/mo</small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>40 Hours / Month</li>
                        <li>Emergency Availability</li>
                        <li>24/7 On Call Support</li>
                        <li>3 Month Minimum</li>
                    </ul>
                    <button id="pricecta03" type="button" class="w-100 btn btn-lg btn-primary hvr-float">Apply Now</button>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card mb-4 rounded-3 shadow-sm" data-aos="flip-left" data-aos-duration="2000" data-aos-delay="300">
                <div class="card-header py-3">
                    <h3 class="">Retainer Pro</h3>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">$5,000<small class="text-body-secondary fw-light">/mo</small></h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>100 Hours / Month</li>
                        <li>Emergency Availability</li>
                        <li>24/7 On Call Support</li>
                        <li>6 Month Minimum</li>
                    </ul>
                    <button id="pricecta04" type="button" class="w-100 btn btn-lg btn-primary hvr-float">Apply Now</button>
                </div>
            </div>
        </div>
    </div>
</div>