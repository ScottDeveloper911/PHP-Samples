<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">SEO/SEM</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/seo-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">SEO</h3>
                <p>Get your site SEOed properly and get your pages searchable.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/google-ads-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Google Ads</h3>
                <p>We setup, manage and optimize Google Ad.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/facebook-ads-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Facebook Ads</h3>
                <p>We setup, manage and optimize Facebook Ad.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/google-search-console-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Search Console</h3>
                <p>Get your site on google and optimize your score.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-01" src="img/advertising-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/seo-01-blue.png"> SEO</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Getting your SEO in order can be easy in most cases. In other cases where you might have 1,000+ product pages or blog posts. Then it becomes much more of a challenge. In either case we are ready to take on your SEO project. We have worked with clients with over 7,000 blog pages which all needed to be uniquely SEOed.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/google-ads-01-blue.png"> Google Ads</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Wether you call it Google Ads or Adwords we have been doing it for over 15 years. We have managed over 3 million in adspend in the last 10 years alone. We have worked with many different demographics and products over the years. We can help with new campaigns or get an old campaign going again. We have the experiance to get your ROIs up.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/facebook-ads-01-blue.png"> Facebook Ads</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We started running facebook ads back in the early 2000's with Garcinia Cambogia products. We rode the 'Dr.oz' wave all the way til regulations changed. We have been running legitimate PCI compliance ads and landers ever since. We have designers who create all the creatives and copy writers who do all the copy.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/google-search-console-01-blue.png"> Search Console</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We absolutely love Google Search Engine Console! It used to be a daunting task to get google bots to crawl your pages for indexing. Now you can easily submit, manage and optimize your pages with google search console. This makes getting indexed much quicker then in past decades. They even offer extra services and page scoring to help maximize the google searchability. This is a must have for any company that wants to take their SEO seriously.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/advertising-img-02.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>