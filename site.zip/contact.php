<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center" data-aos="fade-up" data-aos-duration="2000">Contact Our Team</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
</div>
<form id="contactform" action="https://legitdevelopers.com/mailer/send.php" method="post">
<!-- Contact Form -->
<div class="container-fluid">
    <div class="row">
        <div class="d-none d-sm-block col-md-3 col-lg-3">

        </div>
        <div class="col-sm-12 col-md-6 col-lg-6 text-center">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="form-box-01">
                        <label class="form-label" for="fname">First Name <span id="fnamemsg"></span></label>
                        <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="form-box-01">
                        <label class="form-label" for="fname">Last Name <span id="lnamemsg"></span></label>
                        <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="form-box-01">
                        <label class="form-label" for="company">Company <span id="companymsg"></span></label>
                        <input type="text" class="form-control" id="company" name="company" placeholder="Company">
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="form-box-01">
                        <label class="form-label" for="email">Email <span id="emailmsg"></span></label>
                        <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-box-01">
                        <label class="form-label" for="message">Message <span id="messagemsg"></span></label>
                        <textarea class="form-control" id="message" name="message" rows="4" cols="50"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4">
                    <img id="checkerimg" class="pt-4" src="">
                </div>
                <div class="col-8">
                    <label class="form-label" for="match">Match The Image <span id="matchmsg"></span></label>
                    <select class="form-control" name="match" id="match">
                        <option value="">Choose</option>
                        <option value="1">Light Bulb</option>
                        <option value="2">Rocket Ship</option>
                        <option value="3">Clock</option>
                        <option value="4">Trophy</option>
                        <option value="5">Puzzle</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <br>
                    <button id="contactformbtn01" type="submit" class="w-100 btn btn-lg btn-primary hvr-float">Submit Request</button>
                </div>
            </div>
        </div>
        <div class="d-none d-sm-block col-md-3 col-lg-3">

        </div>
    </div>
</div>
</form>
<br><br><br>
<?php
include('footer.php');
?>