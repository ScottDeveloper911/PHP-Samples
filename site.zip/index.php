<?php
include('header.php');
?>

<!-- Carousel -->
<div id="carID" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active" style="max-height: 400px;overflow: hidden;" data-bs-interval="20000">
            <!-- <img src="img/slider-bg-ph-02.jpg" class="d-block w-100" alt="..."> -->
            <video loop muted autoplay>
                <source src="https://legitdevelopers.com/img/1418343_Code_Web_Cyberspace_3840x2160.mp4" type="video/mp4">
                Your browser does not support HTML video.
            </video>
            
            <div class="carousel-caption d-none d-md-block">
                <p class="slide-title-01" data-aos="fade-up" data-aos-duration="2000"></p>
                <p class="slide-font-01" data-aos="fade-up" data-aos-duration="2000"></p>
            </div>
        </div>
        <div class="carousel-item" style="max-height: 400px;overflow: hidden;" data-bs-interval="20000">
            <!-- <img src="img/slider-bg-ph-02.jpg" class="d-block w-100" alt="..."> -->
            <video loop muted autoplay>
                <source src="https://legitdevelopers.com/img/1418343_Code_Web_Cyberspace_3840x2160.mp4" type="video/mp4">
                Your browser does not support HTML video.
            </video>
            <div class="carousel-caption d-none d-md-block">
                <p class="slide-title-02" data-aos="fade-up" data-aos-duration="2000"></p>
                <p class="slide-font-02" data-aos="fade-up" data-aos-duration="2000"></p>
            </div>
        </div>
    </div>
</div>

<!-- Featured -->
<div class="container-fluid px-4 py-5 bg-sides-01" id="icon-grid">
    <h1 class="pb-4 border-bottom text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">How may we help you today?</h1>
    <div class="max-width-01">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/websites-02-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">Websites</h3>
                    <p>We design, build and maintain websites in all demographics.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/funnels-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">Funnels</h3>
                    <p>We build high converting funnels and landing pages.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/api-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">APIs</h3>
                    <p>We can work with any REST API, API or 3rd Party Integrations.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/seo-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">SEO/SEM</h3>
                    <p>We setup and optimize SEO and SEM campaigns on all platforms.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/ui-design-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">UI/UX Design</h3>
                    <p>We have a professional UI/UX designer of more then 15 years.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/tracking-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">Tracking/Analytics</h3>
                    <p>We can setup any tracking your business' needs.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/consulting-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">Consulting</h3>
                    <p>We can help get your project on track and provide suggestions.</p>
                </div>
            </div>
            <div class="col d-flex align-items-start">
                <img class="icon-02" src="img/team-01-dblue.png" data-aos="fade-up" data-aos-duration="2000">
                <div data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 font-color-01">Our Team</h3>
                    <p>We have high level developers and designers on our team.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Emergency -->
<div class="px-4 pt-1 pb-5 my-5 text-center">
    <h1 class="text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Do You Have an Emergency?</h1>
    <div class="col-lg-6 mx-auto">
        <p class="lead mb-4" data-aos="fade-up" data-aos-duration="2000">We have a team of developers and designers on call 24/7. This availability is for our retainer clients as part of the retainment. We do however offer emergency services for clients at an emergency hourly rate. Either way we are happy to help get your emergency taken care of.</p>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <button id="contactbtn01" type="button" class="btn btn-outline-primary btn-lg px-4 gap-3 hvr-float">Contact Us</button>
        </div>
    </div>
</div>

<!-- What sets us apart -->
<div class="container-fluid px-4 bg-blue-01">
    <div class="row row-cols-1 row-cols-md-2 align-items-md-center g-5 px-4">
        <div class="col-12 col-sm-6 col-md-7 col-lg-7">
            <h1 class="fw-bold text-body-emphasis text-white-01" data-aos="fade-up" data-aos-duration="2000">What Sets Us Apart From Other Teams?</h1>
            <p class="text-body-secondary text-white-01" data-aos="fade-up" data-aos-duration="2000">We set our egos aside and work together to get the job done. Our team is our family and all love what we do. Top quality work done before deadlines is our goal. We set our egos aside and work together to get the job done. Our team is our family and all love what we do. Top quality work done before deadlines is our goal. We set our egos aside and work together to get the job done. Our team is our family and all love what we do. Top quality work done before deadlines is our goal.</p>
            <a href="https://legitdevelopers.com/rebuild/contact.php" class="btn btn-outline-light btn-lg hvr-float">Request A Consultation</a>
        </div>
        <div class="col-12 col-sm-6 col-md-5 col-lg-5">
            <div class="row row-cols-1 row-cols-sm-2 g-4">
                <div class="col d-flex flex-column gap-2">
                    <center>
                    <img class="icon-03" src="img/quality-01-white.png" data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 text-white-01" data-aos="fade-up" data-aos-duration="2000">Quality</h3>
                    <p class="text-white-01" data-aos="fade-up" data-aos-duration="2000">We pride ourselves on high quality work done on time.</p>
                    </center>
                </div>
                <div class="col d-flex flex-column gap-2">
                    <center>
                    <img class="icon-03" src="img/communication-01-white.png" data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 text-white-01" data-aos="fade-up" data-aos-duration="2000">Communication</h3>
                    <p class="text-white-01" data-aos="fade-up" data-aos-duration="2000">Our team is USA based and speak clear english.</p>
                    </center>
                </div>
                <div class="col d-flex flex-column gap-2">
                    <center>
                    <img class="icon-03" src="img/honesty-01-white.png" data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 text-white-01" data-aos="fade-up" data-aos-duration="2000">Honesty</h3>
                    <p class="text-white-01" data-aos="fade-up" data-aos-duration="2000">We will be 100% honest even at the loss of projects.</p>
                    </center>
                </div>
                <div class="col d-flex flex-column gap-2">
                    <center>
                    <img class="icon-03" src="img/experiance-02-white.png" data-aos="fade-up" data-aos-duration="2000">
                    <h3 class="fw-bold mb-0 fs-4 text-white-01" data-aos="fade-up" data-aos-duration="2000">Experiance</h3>
                    <p class="text-white-01" data-aos="fade-up" data-aos-duration="2000">We require a minimum of 15 years experiance.</p>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<!-- Split 1 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-01">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/choose-01.png"> Why Choose Us For Your Project?</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/unique-01.png"> What Is Unique About Our Team?</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 2 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold font-color-01" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/team-01-blue.png"> About Our Team</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-02">
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-01">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/websites-02.png"> Websites</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/funnels-01.png"> Funnels</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold font-color-01" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/seo-01-blue.png"> SEO/SEM</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <br>
            <h3 class="fw-bold font-color-01" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/api-01-blue.png"> APIs</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-02">
        </div>
    </div>
</div>

<!-- Split 5 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-01">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/ui-design-01.png"> Web Design</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 6 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold font-color-01" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/ui-design-01-blue.png"> UI/UX Design</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-02">
        </div>
    </div>
</div>

<!-- CTA 2 -->
<div class="container bg-white-01 my-5 hide">
    <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
        <div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
            <h1 class="" data-aos="fade-up" data-aos-duration="2000">Professional UI/UX Designer</h1>
            <p class="lead" data-aos="fade-up" data-aos-duration="2000">Quickly design and customize responsive mobile-first sites with Bootstrap, the world’s most popular front-end open source toolkit, featuring Sass variables and mixins, responsive grid system, extensive prebuilt components, and powerful JavaScript plugins.</p>
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
                <a href="https://legitdevelopers.com/rebuild/contact.php" class="btn btn-primary btn-lg hvr-float">Request A Consultation</a>
            </div>
        </div>
        <div class="col-lg-4 offset-lg-1 p-0 overflow-hidden">
            <img class="placeholder-03" src="img/placeholder-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<!-- Split 7 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-01">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/tracking-01.png"> Tracking/Analytics</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 8 -->
<div class="container-fluid hide">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 bg-white-01">
            <h3 class="fw-bold font-color-01" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/consulting-01-blue.png"> Consulting</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 placeholder-02">
        </div>
    </div>
</div>

<?php
include('footer.php');
?>