<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Websites</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start">
            <img class="icon-02" src="img/frontend-01-blue.png" data-aos="fade-up" data-aos-duration="2000">
            <div>
                <h3 class="fw-bold mb-0 fs-4" data-aos="fade-up" data-aos-duration="2000">Front End</h3>
                <p data-aos="fade-up" data-aos-duration="2000">Anything dealing with HTML, CSS, JS and Browsers.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start">
            <img class="icon-02" src="img/backend-01-blue.png" data-aos="fade-up" data-aos-duration="2000">
            <div>
                <h3 class="fw-bold mb-0 fs-4" data-aos="fade-up" data-aos-duration="2000">Back End</h3>
                <p data-aos="fade-up" data-aos-duration="2000">Anything dealing with server side functions and languages.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start">
            <img class="icon-02" src="img/integration-01-blue.png" data-aos="fade-up" data-aos-duration="2000">
            <div>
                <h3 class="fw-bold mb-0 fs-4" data-aos="fade-up" data-aos-duration="2000">Integrations</h3>
                <p data-aos="fade-up" data-aos-duration="2000">Connecting different software via API or 3rd party integration.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start">
            <img class="icon-02" src="img/maintenance-01-blue.png" data-aos="fade-up" data-aos-duration="2000">
            <div>
                <h3 class="fw-bold mb-0 fs-4" data-aos="fade-up" data-aos-duration="2000">Maintenance</h3>
                <p data-aos="fade-up" data-aos-duration="2000">Ongoing service to maintain the project regularly.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-01" src="img/web-design-img-03.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/frontend-01-blue.png" data-aos="fade-up" data-aos-duration="2000"> Front End</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Frontend Development would be everything on the front end of the site. This would include things like HTML, CSS, Javascript, and Jquery. HTML & CSS provide the structure, look and feel of the frotnend of the site. Where as Javascript & Jquery are used to create movement, interact with browsers, and other frontend functionality.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/backend-01-blue.png" data-aos="fade-up" data-aos-duration="2000"> Back End</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Backend Development is a much wider topic due to the amount of tasks you can do. In website terms backend would be dealing with Databases, Server Side Languages, Webserver, DNS Handlers and much more. We typically use Ubuntu Servers on a LEMP or LAMP stack. Our prefered server side language would be PHP. We are able to work with all server types and languages but our greatest experiance is with PHP.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/integration-01-blue.png" data-aos="fade-up" data-aos-duration="2000"> Integrations</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Integrations come in several forms. Typically you will have an API, REST API, or 3rd Party Integration like 'Zapier'. Based on your demographic you may need some integrations like CRM, CMS, Analytics and other platforms needing to communicate. Having the data transfer properly from system to system is very important. Sometimes the 3rd party softwares will not present the data in the form you need. In those cases we would setup midware to alter the data before it's final destination.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/maintenance-01-blue.png" data-aos="fade-up" data-aos-duration="2000"> Maintenance</h3>
            <p data-aos="fade-up" data-aos-duration="2000">All sites no matter the size or revenue will need occasional updates. Programming languages that most web software are built on update frequiently. When a major change happens everyone will need to upgrade. On a frontend point of view every website will need to update plguins or even just wording on their website. We are here for anything that you may need on a regular basis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/api-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>