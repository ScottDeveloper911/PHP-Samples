<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Our Team</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/developer-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Developer</h3>
                <p>We have a team of High Level Full Stack Developers.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/ux-ui-designer-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">UX/UI Designer</h3>
                <p>We have a highly claimed professional UX/UI Designer.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/our-goal-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Our Goal</h3>
                <p>To provide the highest quality work while meeting deadlines.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/our-dream-02-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">The Dream</h3>
                <p>Employ thousands of Developers & Designers with full benefits.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-03" src="img/developer-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/developer-01-blue.png"> Developers</h3>
            <p data-aos="fade-up" data-aos-duration="2000">All of our developers are 'Full Stack'. This means they have experiance in all levels of web development. From complex API's to styling a button on a page. Every developer on our team has a minimum of 15 years professional experiance as a full stack developer. This allows us to take on many different types of development projects at a high level without cutting corners.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/ux-ui-designer-01-blue.png"> UX/UI Designer</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/our-goal-01-blue.png"> Our Goal</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Our goal is to provide high quality work on or before deadlines. This is easy to say but hard to do. We have a catalog of clients that put their company into our hands because we provide a level of service they can't get anywhere else. We are very loyal to our clients and enjoy seeing them successful.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/our-dream-02-blue.png"> The Dream</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Our dream would be to employ a small army of developers and designers. Ideally with full benefits, PTO, and retirement benfits. We would like to make a stress free no ego work environment where people enjoy working with our team.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/goals-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>