<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">UI/UX Design</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/websites-02-dblue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">TBD</h3>
                <p>Paragraph of text beneath the heading to explain the heading.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/websites-02-dblue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">TBD</h3>
                <p>Paragraph of text beneath the heading to explain the heading.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/websites-02-dblue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">TBD</h3>
                <p>Paragraph of text beneath the heading to explain the heading.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/websites-02-dblue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">TBD</h3>
                <p>Paragraph of text beneath the heading to explain the heading.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/websites-02-dblue.png"> TBD</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/websites-02-dblue.png"> TBD</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/websites-02-dblue.png"> TBD</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/websites-02-dblue.png"> TBD</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis arcu vitae nunc commodo aliquet sed id tellus. Nam eget eros fringilla, facilisis erat vel, consequat magna. Integer porta, velit quis egestas venenatis, erat felis ultrices lacus, ut elementum elit mauris non arcu. Suspendisse vitae dapibus leo. Proin consectetur odio nec laoreet tincidunt. Duis vel luctus lectus. Mauris gravida sem ut placerat tincidunt. Suspendisse maximus est felis, quis dignissim est placerat at. Nulla nec nunc sed mauris pulvinar ullamcorper non sit amet turpis.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>