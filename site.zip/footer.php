<!-- Footer -->
<div id="footer" class="container-fluid px-5 text-center">
    <footer class="pt-4">
        <div class="row">
        <div class="col-12">
            <p class="footertext-01">© <?Php echo date("Y"); ?> Legit Developers, Inc.</p>
        </div>
    </footer>
</div>

<script>
  AOS.init();
</script>

</body>
</html>