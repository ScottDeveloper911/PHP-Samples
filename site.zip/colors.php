<style>
body {
    background-color: #dcdcdc;
    padding: 15px 15px 15px 15px;
    margin: 0px 0px 0px 0px;
}
.color-01, .color-dark-01, .color-light-01, .color-02, .color-dark-02, .color-light-02, .color-03, .color-dark-03, .color-light-03, .color-04, .color-dark-04, .color-light-04, .color-05, .color-dark-05, .color-light-05, .color-06, .color-dark-06, .color-light-06, .color-07, .color-dark-07, .color-light-07 {
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.color-01 {
    height: 55px;
    background-color: #6155B4;
}
.color-dark-01 {
    height: 25px;
    background-color: #574da0;
}
.color-light-01 {
    height: 55px;
    border: 4px solid #6155B4;
    background-color: #fff;
}
.color-02 {
    height: 55px;
    background-color: #772787;
}
.color-dark-02 {
    height: 25px;
    background-color: #6c247b;
}
.color-light-02 {
    height: 55px;
    border: 4px solid #772787;
    background-color: #fff;
}
.color-03 {
    height: 55px;
    background-color: #8a2be2;
}
.color-dark-03 {
    height: 25px;
    background-color: #8229d5;
}
.color-light-03 {
    height: 55px;
    border: 4px solid #8a2be2;
    background-color: #fff;
}
.color-04 {
    height: 55px;
    background-color: #4B0082;
}
.color-dark-04 {
    height: 25px;
    background-color: #560393;
}
.color-light-04 {
    height: 55px;
    border: 4px solid #4B0082;
    background-color: #fff;
}
.color-05 {
    height: 55px;
    background-color: #2a007a;
}
.color-dark-05 {
    height: 25px;
    background-color: #ff5701;
    border-right: 4px solid #2a007a;
    border-left: 4px solid #2a007a;
}
.color-light-05 {
    height: 55px;
    border: 4px solid #2a007a;
    background-color: #fff;
}
.color-06 {
    height: 55px;
    background-color: #44469d;
}
.color-dark-06 {
    height: 25px;
    background-color: #ed208f;
    border-right: 4px solid #44469d;
    border-left: 4px solid #44469d;
}
.color-light-06 {
    height: 55px;
    border: 4px solid #44469d;
    background-color: #fff;
}
.color-07 {
    height: 55px;
    background-color: #9c2cbc;
}
.color-dark-07 {
    height: 25px;
    background-color: #f4b109;
    border-right: 4px solid #9c2cbc;
    border-left: 4px solid #9c2cbc;
}
.color-light-07 {
    height: 55px;
    border: 4px solid #9c2cbc;
    background-color: #fff;
}
</style>
<body>
<div class="color-01"></div>
<div class="color-dark-01"></div>
<div class="color-light-01"></div>
<br><br>
<div class="color-02"></div>
<div class="color-dark-02"></div>
<div class="color-light-02"></div>
<br><br>
<div class="color-03"></div>
<div class="color-dark-03"></div>
<div class="color-light-03"></div>
<br><br>
<div class="color-04"></div>
<div class="color-dark-04"></div>
<div class="color-light-04"></div>
<br><br>
<div class="color-05"></div>
<div class="color-dark-05"></div>
<div class="color-light-05"></div>
<br><br>
<div class="color-06"></div>
<div class="color-dark-06"></div>
<div class="color-light-06"></div>
<br><br>
<div class="color-07"></div>
<div class="color-dark-07"></div>
<div class="color-light-07"></div>
</body>
