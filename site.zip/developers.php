<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Developers</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/future-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Future Project</h3>
                <p>Lay down the roadmap to a future project of your dreams.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/current-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Current Project</h3>
                <p>Let us help you with an existing project that needs help.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/react-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">React.js Apps</h3>
                <p>We build and work on react.js Projects and Apps.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/consulting-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Consulting</h3>
                <p>We are happy to consult on any projects you may have.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-01" src="img/projects-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/future-01-blue.png"> Future Project</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We can help build a roadmap to a future project you may have. It is very important to get a clear idea of what you will need when creating budgets and timeframes. Alot of people forget this step and end up paying way more then they budgeted for. So make sure to get with us in advance so we can make sure you stay on budget and on time.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/current-01-blue.png"> Current Project</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Often clients will have a code base that has been touched by many different development teams. Don't stress we got you here too! We specialize in fixing, re-writing, and updating poorly writen code. In some cases other developers will tell clients they cannot do something when it is actually very simple to do. This is where we come in and get your dream task list knocked out. Alot of the time it will just be an experiance issue. If you have never done it before sometimes it may seem impossible until someone comes along and does it.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/react-01-blue.png"> React.js Apps</h3>
            <p data-aos="fade-up" data-aos-duration="2000">One of our new services is React Apps. We love react.js and dove in head first with react.js 18. We have built out many apps and now feel comfortable offering to our clients. We can also update or work on your older react.js apps. Depending on your Apps need this will be by quote only pricing.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/consulting-01-blue.png"> Consulting</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Often a client need some advice and some direction on a dream project of theirs. Other times a client will need an outside developer to give them some insight on their site. Whatever the case may be we are here to help. We have no egos over here and are happy to just offer counseling, suggestions and ideas without disrupting your current development team.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-04" src="img/consulting-img-03.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>