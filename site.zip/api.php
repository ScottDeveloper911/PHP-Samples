<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">APIs</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/rest-api-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">REST APIs</h3>
                <p>We work with all REST APIs accross all platforms.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/custom-api-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Custom APIs</h3>
                <p>We can build and work on custom APIs on all platforms.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/midware-api-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">API Midware</h3>
                <p>We can manipulate your API data as desired.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/3rd-party-api-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">3rd Party APIs</h3>
                <p>We can setup 3rd party APIs like 'Zapier' platforms.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-03" src="img/api3-img-03.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/rest-api-01-blue.png"> REST APIs</h3>
            <p data-aos="fade-up" data-aos-duration="2000">REST APIs by nature are easy to setup and use. Although the tasks you can perform varies depending on the REST API you are working with. We can help navigate your REST API projects. It is important to set these APIs up properly the first time so you don't have issues when sending data. REST APIs should remain simple and clean with little complexity. This will ensure the best outcome for your REST API setup.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/custom-api-01-blue.png"> Custom APIs</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Were you don't have the option to use a REST API you will need a Custom API. This can be a company API or just a private API. Either way we can help setup your Custom APIs. Alot of developers will tell you it is impossible to connect different software together via APIs. We don't accept that and have setup many challanging Custom APIs with high success. This is another case of sometimes the other development teams don't have the experiance to create Custom API setups with sucess.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/midware-api-01-blue.png"> API Midware</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Often the data being sent over an API will not be in the proper format for the reciver. So the data will need to be manipulated before it is sent over to its final destination. This is what we call 'midware' in the development world. It resides in the middle of 2 API sequences. This can expand your current APIs by offering custom formats for data. You can even inject code in the midware to make decisions. This could include sending data to different software based on the chosen logic.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/3rd-party-api-01-blue.png"> 3rd Party APIs</h3>
            <p data-aos="fade-up" data-aos-duration="2000">3rd Party integrations are often the easiest to setup and maintain. For simple integrations we highly suggest just using a 3rd party. It will save time and money in the long run. Plus there are teams of devs making sure your integrations are up and running 24/7. We are happy to setup these integrations for you. As we said it it normally quick and painless.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/api-2-img-02.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>