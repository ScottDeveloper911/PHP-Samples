<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Tracking</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/basic-tracking-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Basic Tracking</h3>
                <p>We can setup your basic analytics and conversion tracking.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/custom-tracking-02-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Custom Tracking</h3>
                <p>We also setup custom tracking and A/B testing tracking.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/snippet-tracking-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Snippets</h3>
                <p>We use GTM typically for tracking snippet management.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/data-visualization-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Data Visualization</h3>
                <p>We use Data Studio typically to setup data visualizations.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-01" src="img/analytics-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/basic-tracking-01-blue.png"> Basic Tracking</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Every website big or small needs at least basic analytics. You have to know where your at to know where you are going. Basic tracking is often just Google Analytics and Maybe Google Tag Manager setup. This is a quick and easy way to get the basics of your website. There are no excuses for not having at least basic analytics. This can often be done within 30 minutes if you have the Google Accounts created already.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/custom-tracking-02-blue.png"> Custom Tracking</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Often you will want custom tracking setup for sales based sites or affiliate marketing. In these cases you will sometimes have hundreds of ads running to multiple CRMs and data management softwares. It is critically important to have your tracking setup correctly so you get payed and affiliated get paid properly. We have the experiance setting up elaborate custom tracking setups over the last 15 years.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/snippet-tracking-01-blue.png"> Snippets</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Most tracking software will provide javascript snippets to add to your website. These can be basic analytics or even conversion snippets. We highly suggest you use Google Tag Manager so you can easily manage all of your snippets without having to edit your website directly. Tag Manager also allows custom trigger events for easily managing basic conversion events with no coding experiance needed. This is great for companies that work with affiliate who provide a lot of different snippets to implement.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/data-visualization-01-blue.png"> Data Visualization</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Often considered a luxury data visualization takes raw data and turns it into a visual representaion. The data is normally viewed in its raw form just fine by most. Although when you want to present the data to others it is nice to have it look amazing! We exclusively use Googles Data Studio for our clients. It is very easy to bring in many sources of data to display.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/analytics2-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>