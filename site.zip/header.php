<!DOCTYPE html>
<html lang="en">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/x-icon" href="img/cropped-favicon1-32x32.png">
<link rel="icon" href="img/cropped-favicon1-32x32.png" sizes="32x32" />
<link rel="icon" href="img/cropped-favicon1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="img/cropped-favicon1-180x180.png" />
<meta name="msapplication-TileImage" content="img/cropped-favicon1-270x270.png" />
<?php
include('seo.php');
?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TXZBLNP5');</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-TDFXNQ3SVQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-TDFXNQ3SVQ');
</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16452787724">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16452787724');
</script>
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css" integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e" crossorigin="anonymous">
<!-- Jquery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
<!-- Custom -->
<link href="css/hover.css" rel="stylesheet" media="all">
<link href="css/custom.css?v=<?php echo date("Y/m/d hh:mm:ss") ?>" rel="stylesheet" media="all">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
// --------------------------------------------------------------------
// Function - Check Email
// --------------------------------------------------------------------
function validateEmail(email) {
    var regex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
    return regex.test(email);
}

// --------------------------------------------------------------------
// Function - Check Phone
// --------------------------------------------------------------------
function validatePhoneNumber(input_str) {
    var re = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    return re.test(input_str);
}

// --------------------------------------------------------------------
//
// Function - Check Info
//
// --------------------------------------------------------------------
function checkInfo() {
    let errors = 0;
    // --------------------------------------------------------------------
    // Check First Name for errors
    // --------------------------------------------------------------------
    if ($('#fname').val() === '') {
        $("#fnamemsg").show();
        document.getElementById("fnamemsg").innerHTML = " is Required";
        errors++;
    } else {
        $("#fnamemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Last Name for errors
    // --------------------------------------------------------------------
    if ($('#lname').val() === '') {
        $("#lnamemsg").show();
        document.getElementById("lnamemsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#lnamemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Message for errors
    // --------------------------------------------------------------------
    if ($('#message').val() === '') {
        $("#messagemsg").show();
        document.getElementById("messagemsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#messagemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Company for errors
    // --------------------------------------------------------------------
    if ($('#company').val() === '') {
        $("#companymsg").show();
        document.getElementById("companymsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#companymsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Match for errors
    // --------------------------------------------------------------------
    let checkerurl = $("#checkerimg").attr('src');
    let result = checkerurl.slice(13, 14);
    //
    if ($('#match').val() === '') {
        $("#matchmsg").show();
        document.getElementById("matchmsg").innerHTML = "- is Required";
        errors++;
    } else {
        if ($('#match').val() === result){
            $("#matchmsg").hide();
            console.log("Not Empty & Matches");
        } else {
            $("#matchmsg").show();
            document.getElementById("matchmsg").innerHTML = "- Doesn't Match!";
            errors++;
            console.log("Not Empty & Does NOT Matches");
        }
    }
    // --------------------------------------------------------------------
    // Check Email for errors
    // --------------------------------------------------------------------
    let grabEmail = $('#email').val();
    let checkRegxEmail = validateEmail(grabEmail);
    if (grabEmail === '' || checkRegxEmail === false) {
        $("#emailmsg").show();
        document.getElementById("emailmsg").innerHTML = "is Invalid";
        errors++;
    } else {
        $("#emailmsg").hide();
    }
    
    // --------------------------------------------------------------------
    // Check for errors
    // --------------------------------------------------------------------
    if (errors > 0) {
        // Has Errors
        console.log('Has Errors: ' + errors);
        return false;
    } else {
        // No Errors
        console.log('No Errors: ' + errors);
        return true;
    }
}

// --------------------------------------------------------------------
//
// Function - Check Apply
//
// --------------------------------------------------------------------
function checkApply() {
    let errors = 0;
    // --------------------------------------------------------------------
    // Check First Name for errors
    // --------------------------------------------------------------------
    if ($('#fname').val() === '') {
        $("#fnamemsg").show();
        document.getElementById("fnamemsg").innerHTML = " is Required";
        errors++;
    } else {
        $("#fnamemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Last Name for errors
    // --------------------------------------------------------------------
    if ($('#lname').val() === '') {
        $("#lnamemsg").show();
        document.getElementById("lnamemsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#lnamemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Needs for errors
    // --------------------------------------------------------------------
    if ($('#needs').val() === '') {
        $("#needsmsg").show();
        document.getElementById("needsmsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#needsmsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Company for errors
    // --------------------------------------------------------------------
    if ($('#company').val() === '') {
        $("#companymsg").show();
        document.getElementById("companymsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#companymsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Website for errors
    // --------------------------------------------------------------------
    if ($('#website').val() === '') {
        $("#websitemsg").show();
        document.getElementById("websitemsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#websitemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Type for errors
    // --------------------------------------------------------------------
    if ($('#type').val() === '') {
        $("#typemsg").show();
        document.getElementById("typemsg").innerHTML = " is Required";
        errors++;
    } else {
        //
        $("#typemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Match for errors
    // --------------------------------------------------------------------
    let checkerurl = $("#checkerimg").attr('src');
    let result = checkerurl.slice(13, 14);
    //
    if ($('#match').val() === '') {
        $("#matchmsg").show();
        document.getElementById("matchmsg").innerHTML = "- is Required";
        errors++;
    } else {
        if ($('#match').val() === result){
            $("#matchmsg").hide();
            console.log("Not Empty & Matches");
        } else {
            $("#matchmsg").show();
            document.getElementById("matchmsg").innerHTML = "- Doesn't Match!";
            errors++;
            console.log("Not Empty & Does NOT Matches");
        }
    }
    // --------------------------------------------------------------------
    // Check Email for errors
    // --------------------------------------------------------------------
    let grabEmail = $('#email').val();
    let checkRegxEmail = validateEmail(grabEmail);
    if (grabEmail === '' || checkRegxEmail === false) {
        $("#emailmsg").show();
        document.getElementById("emailmsg").innerHTML = "is Invalid";
        errors++;
    } else {
        $("#emailmsg").hide();
    }
    // --------------------------------------------------------------------
    // Check Phone for errors
    // --------------------------------------------------------------------
    let grabPhone = $('#phone').val();
    let checkRegxPhone = validatePhoneNumber(grabPhone);
    if (grabPhone === '' || checkRegxPhone === false) {
        $("#phonemsg").show();
        document.getElementById("phonemsg").innerHTML = "Invalid Phone";
        errors++;
    } else {
        $("#phonemsg").hide();
    }
    // --------------------------------------------------------------------
    // Check for errors
    // --------------------------------------------------------------------
    if (errors > 0) {
        // Has Errors
        console.log('Has Errors: ' + errors);
        return false;
    } else {
        // No Errors
        console.log('No Errors: ' + errors);
        return true;
    }
}

$(document).ready(function(){
    $("#contactbtn01").click(function(){
        window.location.href = "contact.php";
    });
    $("#pricingbtn01").click(function(){
        window.location.href = "pricing.php";
    });
    
    $("#pricecta01").click(function(){
        window.location.href = "contact.php";
    });
    $("#pricecta02").click(function(){
        window.location.href = "contact.php";
    });
    $("#pricecta03").click(function(){
        window.location.href = "application.php";
    });
    $("#pricecta04").click(function(){
        window.location.href = "application.php";
    });
    //
    $(".navbar-toggler").click(function(){
        $("#logo").toggle();
    });
    //
    $("#contactform").submit(function(){
        if (checkInfo()) {
            // Passed Validation
            console.log('Safe to submit form.');
            $("#contactform").submit();
        } else {
            event.preventDefault()
        }
    });
    $("#applyform").submit(function(){
        if (checkApply()) {
            // Passed Validation
            console.log('Safe to submit form.');
            $("#applyform").submit();
        } else {
            event.preventDefault()
        }
    });
    //
    function randImage() {
        let grn = Math.floor(Math.random() * 5) + 1;
        let burl = "img/checker-0" + grn + ".png";
        $("#checkerimg").attr('src', burl);
    }
    randImage();
    
});
</script>

<style>
#fnamemsg, #lnamemsg, #emailmsg, #messagemsg, #matchmsg, #phonemsg, #companymsg, #websitemsg, #typemsg, #needsmsg {
    display: none;
    color: red !important;
}
select {
    color: #c8c7c8 !important;
}
.max-width-01 {
    width: 100%;
    max-width: 1150px;
    margin: 0px auto 0px auto;
}
.section-01 {
    min-height: 700px;
}
.logo-01 {
    width: 100%;
    max-width: 80px;
    padding: 0px 0px 0px 0px;
    margin: 15px auto 0px auto;
    position: relative;
    align-content: center;
    display: flex;
}
.navbar-nav {
    margin: 0px auto 0px auto;
    background-image: url('');
}
.navbar {
    background-image: url('img/nav-bg-01.png');
    background-size: cover;
    background-repeat: no-repeat;
    position: absolute;
    width: 100%;
    min-height: 180px;
    --bs-bg-opacity: 0 !important;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
    display: block;
    z-index: 1;
    background-position: center;
}
.nav-link {
    color: #fff;
    font-size: 20px;
    font-family: 'Gabarito', sans-serif;
}
.nav-link:hover {
    color: #f2f2f2;
    background-color: transparent;
}
h5, h1 {
    font-weight: bold;
    font-family: 'Gabarito', sans-serif;
}
h3 {
    color: #2684e5;
    font-family: 'Gabarito', sans-serif;
}
p {
   font-family: 'Roboto', sans-serif; 
}
.icon-01 {
    font-size: 40px;
    padding: 10px;
}
.icon-02 {
    width: 100%;
    max-width: 55px;
    padding: 18px 10px 5px 5px;
    margin: 0px 0px 0px 0px;
}
.icon-03 {
    width: 100%;
    max-width: 75px;
    padding: 18px 10px 5px 5px;
    margin: 0px 0px 0px 0px;
}
.icon-04 {
    width: 100%;
    max-width: 45px;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.btn-primary {
    font-weight: bold !important;
    background-color: #2684e5 !important;
    border: 1px solid #2684e5 !important;
    font-family: 'Gabarito', sans-serif !important;
    box-shadow: 0px 4px #1463b4 !important;
}
.placeholder-01 {
    height: 500px;
    background-image: linear-gradient(to right, #e0e0e0 , #fff);
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.placeholder-02 {
    height: 500px;
    background-image: linear-gradient(to left, #e0e0e0 , #fff);
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.placeholder-03 {
    width: 100%;
    max-width: 700px;
    padding: 0px 10px 45px 0px;
    margin: 0px 0px 0px 0px;
}
.hr-01 {
    width: 80%;
}
.hr-02 {
    color: #2684e5;
    width: 100%;
    max-width: 500px;
    margin: 0px auto 0px auto;
}
.title-mods-01 {
    border-bottom: 1px solid #86189a;
    padding-bottom: 10px;
    margin-bottom: 15px;
}
.form-box-01 {
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.form-control {
    width: 100%;
    max-width: 744px;
    padding: 15px;
    margin: 0px auto 0px auto;
    border: 1px solid #c8c7c8;
}
.form-label {
    font-weight: bold;
    font-family: 'Gabarito', sans-serif !important;
    padding: 0px 10px 0px 10px;
    margin: 0px 0px 0px 0px;
    position: relative;
    top: 10px;
    background-color: #fff;
}
::placeholder {
  color: #c8c7c8 !important;
  opacity: 1;
}
body {
    background-image: url('img/bg-pattern-04.jpg');
}
.bg-white-01 {
    background-color: #fff;
}
.slide-title-01 {
    color: #fff;
    font-size: 34px;
    font-weight: bold;
    text-align: left;
    font-family: 'Roboto', sans-serif;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.slide-title-02 {
    color: #000;
    font-size: 34px;
    font-weight: bold;
    text-align: center;
    font-family: 'Roboto', sans-serif;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.slide-font-01 {
    color: #fff;
    font-size: 22px;
    font-weight: normal;
    text-align: left;
    font-family: 'Roboto', sans-serif;
    width: 100%;
    max-width: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.slide-font-02 {
    color: #000;
    font-size: 22px;
    font-weight: normal;
    text-align: center;
    font-family: 'Roboto', sans-serif;
    width: 100%;
    max-width: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
}
.carousel-caption {
    bottom: 100px !important;
}
.square-img-01 {
    width: 100%;
    max-width: 550px;
    max-height: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
    float: right;
}
.square-img-02 {
    width: 100%;
    max-width: 500px;
    max-height: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
    float: left;
}
.square-img-03 {
    width: 100%;
    max-width: 500px;
    max-height: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
    float: right;
}
.square-img-04 {
    width: 100%;
    max-width: 500px;
    max-height: 500px;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
    float: left;
}
.font-color-01 {
    color: #2684e5;
}
.font-color-02 {
    color: #686868;
}
.carousel {
  padding-top: 55px;
}
.bg-sides-01 {
    background-image: url('img/bg-sides-01.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
    background-position: center;
    min-height: 550px;
}
.bg-sides-02 {
    background-image: url('img/bg-sides-02.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
    background-position: center;
    min-height: 550px;
}
.bg-sides-03 {
    background-image: url('img/bg-sides-03.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
    background-position: center;
    min-height: 550px;
}
.bg-blue-01 {
    background-image: url('img/bg-blue-04.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
    background-position: center;
    min-height: 550px;
}
#footer {
    background-image: url('img/bg-footer-01.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
    background-position: center;
    min-height: 150px;
}
.footertext-01 {
    position: relative;
    bottom: -100px;
    font-size: 14px;
    color: #8a8a8a;
    padding: 0px 0px 0px 0px;
    margin: 0px auto 0px auto;
}
.hide {
    display: none !important;
}
.text-white-01 {
    color: #fff !important;
}
.spacer-01 {
    height: 140px;
    padding: 0px 0px 0px 0px;
    margin: 0px 0px 0px 0px;
}
.change-order-01 {
    order: 1;
}
.change-order-02 {
    order: 2;
}
@media only screen and (max-width: 1400px) {
    .carousel {
        padding-top: 65px;
    }
    .spacer-01 {
        height: 140px;
    }
}
@media only screen and (max-width: 1200px) {
    .carousel {
        padding-top: 50px;
    }
    .spacer-01 {
        height: 130px;
    }
    .bg-blue-01 {
        min-height: 670px;
    }
}
@media only screen and (max-width: 992px) {
    .logo-01 {
        top: -30px;
    }
    .navbar {
        min-height: 130px;
    }
}
@media only screen and (max-width: 768px) {
    
}
@media only screen and (max-width: 600px) {
    .nav-link {
        color: #fff;
        font-size: 14px;
        font-family: 'Gabarito', sans-serif;
        padding: 0px 0px 0px 0px;
        margin: 0px 0px 0px 0px;
    }
    .nav-mobile {
        width: 100%;
        display: block;
        padding: 0px 0px 0px 0px;
        margin: 0px auto 0px auto;
    }
    .navbar-nav {
        display: inline;
    }
    #navbarSupportedContent {
        position: relative;
        top: -35px;
        margin: 0px 22% 40px 22%;
    }
    .navbar-toggler {
        margin-top: 10px;
    }
    .navbar-toggler:focus {
        box-shadow: none;
    }
    .bg-blue-01 {
        background-image: url('img/bg-blue-mogile-01.png');
        height: 1550px;
    }
    .change-order-01 {
        order: 2;
    }
    .change-order-02 {
        order: 1;
    }
}
@media only screen and (max-width: 350px) {
    .bg-blue-01 {
        background-image: url('img/bg-blue-mogile-01.png');
        height: 1750px;
    }
}
</style>
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TXZBLNP5"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
            <ul class="navbar-nav mb-2 mb-lg-0">
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="websites.php">Websites</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="developers.php">Developers</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="seo-sem.php">SEO/SEM</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="ui-ux.php">UI/UX Design</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="api.php">APIs</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="tracking.php">Tracking</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="pricing.php">Pricing</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="team.php">Team</a>
                </li>
                <li class="nav-item nav-mobile">
                    <a class="nav-link hvr-grow" href="contact.php">Contact</a>
                </li>
            </ul>
        </div>
    </div>
    <a href="https://legitdevelopers.com"><img id="logo" class="logo-01" src="img/animat-rocket-color.gif"></a>
</nav>