<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center font-color-02" data-aos="fade-up" data-aos-duration="2000">Pricing</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 py-5">
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/quality-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Quality</h3>
                <p>Our team are high level pros with over 15 years experiance each.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/available-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">Availability</h3>
                <p>We are available 24/7 to our retainer clients even on holidays.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/usa-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">USA Based</h3>
                <p>Our team is 100% USA based speaking clear english.</p>
            </div>
        </div>
        <div class="col d-flex align-items-start" data-aos="fade-up" data-aos-duration="2000">
            <img class="icon-02" src="img/no-sales-01-blue.png">
            <div>
                <h3 class="fw-bold mb-0 fs-4">No Sales Team</h3>
                <p>We have no sales staff just develoeprs and Designers.</p>
            </div>
        </div>
    </div>
</div>

<!-- Split 3 -->
<div class="container-fluid bg-sides-02">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6">
            <img class="square-img-01" src="img/quality-availability-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/quality-01-blue.png"> Quality</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We are high level professionals with a minimum of 15 years experiance each. Our developers and designers never cut corners, ever. Our goal is to over deliver on every project. To do this we need a high level team that can get things done in a fraction of the time a lower level developer or designer would. Get your projects done right the first time for now and for the future with us.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/available-01-blue.png"> Availability</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We are available during standard business hours 9am - 5pm PST for standard inqueries. For our retainer clients we are available 24/7 even on holidays. We know your business is important and even a few hours of down time can cause huge revenue issues. That is why we make ourselves available 24/7 in case an emergency happens. If you are not on retainer but have an emergency we are happy to help at our 'Emergency Rate'.</p>
        </div>
    </div>
</div>

<!-- Split 4 -->
<div class="container-fluid bg-sides-03">
    <div class="row">
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 py-4 px-4 change-order-01">
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/usa-01-blue.png"> USA Based</h3>
            <p data-aos="fade-up" data-aos-duration="2000">Our team is 100% based in the USA and speak clear english. We love all cultures and countries around the world but it can be hard to communicate sometimes. Rest assured when you give our team a task we will be able to effectively communicate and get the job done.</p>
            <br>
            <h3 class="fw-bold" data-aos="fade-up" data-aos-duration="2000"><img class="icon-04" src="img/no-sales-01-blue.png"> No Sales Team</h3>
            <p data-aos="fade-up" data-aos-duration="2000">We do not have a sales team or even a single sales person. You talk directly to the developer or designer that will be working on your project. We are not here to sell you on services. We may offer suggestions when consulting but we will never hard sell a product or service.</p>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-6 change-order-02">
            <img class="square-img-02" src="img/usa-img-01.png" data-aos="fade-up" data-aos-duration="2000">
        </div>
    </div>
</div>

<?php
include('sec_pricing.php');
?>

<?php
include('footer.php');
?>