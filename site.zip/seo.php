<?php
// -----------------------------------------------------------
// Grab Current URL
// -----------------------------------------------------------
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    $link = "https";
} else {
    $link = "http";
}
$link .= "://";
$link .= $_SERVER['HTTP_HOST'];
$link .= $_SERVER['REQUEST_URI'];

// -----------------------------------------------------------
// SEO Switch Logic
// -----------------------------------------------------------
switch ($link) {
    // Home
    case "https://legitdevelopers.com/index.php":
        $description = "We are a team of full stack developers that can bring your ideas to life. Our developers have experience with large direct sales &amp; ecom.";
        $clink = "https://legitdevelopers.com/index.php";
        $title = "Developers & Designers";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    case "https://legitdevelopers.com/":
        $description = "We are a team of full stack developers that can bring your ideas to life. Our developers have experience with large direct sales &amp; ecom.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com";
        $title = "Developers & Designers";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Websites
    case "https://legitdevelopers.com/websites.php":
        $description = "We build, fix, and Maintain websites on all platforms.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/websites.php";
        $title = "Websites";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Developers
    case "https://legitdevelopers.com/developers.php":
        $description = "Our team of developers have over 15 years of experiance each.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/developers.php";
        $title = "Developers";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // seo-sem
    case "https://legitdevelopers.com/seo-sem.php":
        $description = "Our team can help get your SEO/SEM dialed in properly with 20+ years of experiance.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/seo-sem.php";
        $title = "SEO/SEM";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // UI-UX
    case "https://legitdevelopers.com/ui-ux.php":
        $description = "We have a professional UI/UX designer with over 20 years of experiance.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/ui-ux.php";
        $title = "UI/UX";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // APIs
    case "https://legitdevelopers.com/api.php":
        $description = "We have the experiance to get your APIs setup properly the first time.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/api.php";
        $title = "APIs";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Tracking
    case "https://legitdevelopers.com/tracking.php":
        $description = "Every website needs tracking/analytics and we are happy to help set those up!";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/tracking.php";
        $title = "Tracking/Analytics";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Pricing
    case "https://legitdevelopers.com/pricing.php":
        $description = "We offer different options depending on your companies needs on our pricing page.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/pricing.php";
        $title = "Pricing";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Teams
    case "https://legitdevelopers.com/team.php":
        $description = "We are a team of full stack developers & UI/UX designers.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/team.php";
        $title = "Our Team";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Contact
    case "https://legitdevelopers.com/contact.php":
        $description = "We are available 24/7 to our clients even on holidays.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/contact.php";
        $title = "Contact";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    // Application
    case "https://legitdevelopers.com/application.php":
        $description = "We are happy to accept retainer requests from our clients.";
        $link = "https://legitdevelopers.com/";
        $clink = "https://legitdevelopers.com/application.php";
        $title = "Apply for Retainer";
        $site = "Legit Developers";
        $modified = "2024-02-03T0013:50:34+00:00";
        $image = "https://legitdevelopers.com/img/social-banner.jpg";
        break;
    default:
        // No Default
}

// -----------------------------------------------------------
// SEO Template
// -----------------------------------------------------------
$template = "<title>". $title ."</title>
<meta name='description' content='". $description ."' />
<link rel='canonical' href='". $clink ."' />
<meta property='og:locale' content='en_US' />
<meta property='og:type' content='website' />
<meta property='og:title' content='". $title ."' />
<meta property='og:description' content='". $description ."' />
<meta property='og:url' content='". $link ."' />
<meta property='og:site_name' content='". $site ."' />
<meta property='article:modified_time' content='". $modified ."' />
<meta property='og:image' content='". $image ."' />
<meta property='og:image:width' content='600' />
<meta property='og:image:height' content='400' />
<meta name='twitter:card' content='summary_large_image' />
<meta name='twitter:image' content='". $image ."' />
<meta name='twitter:label1' content='Est. reading time' />
<meta name='twitter:data1' content='7 minutes' />";
echo $template;
?>