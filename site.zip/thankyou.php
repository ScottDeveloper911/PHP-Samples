<?php
include('header.php');
?>

<div class="spacer-01"></div>

<!-- Featured -->
<div class="container px-4 py-5" id="icon-grid">
    <h1 class="pb-4 text-center" data-aos="fade-up" data-aos-duration="2000">Form Submitted Successfuly</h1>
    <hr class="hr-02" data-aos="fade-up" data-aos-duration="2000">
</div>

<!-- Thank You -->
<div class="container-fluid text-center">
    <div class="row">
        <div class="col-12">
            <p data-aos="fade-up" data-aos-duration="2000">We appriciate your time and will get back with you as soon as possible. We do not have a sales team so a developer or designer will be getting with you personally.</p>
        </div>
    </div>
</div>

<br><br><br>
<?php
include('footer.php');
?>